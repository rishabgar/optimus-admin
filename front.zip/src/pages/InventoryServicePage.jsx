// import React from "react";

export default function InventoryServicePage() {
    return <div>InventoryServicePage</div>;
}
